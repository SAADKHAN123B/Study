 
## 📜 Commands

| Command | Description |
|---------|-------------|
| `/start` | Start the bot |
| `/stop`  | Stop the bot |
| `/help`  | Show help message |

---
